

<?php $__env->startSection('main'); ?>
<div class="container py-5">
    <!-- Header Section -->
    <div class="mb-5">
        <div style="border-left: 4px solid <?php echo e($team->color); ?>; padding-left: 1rem;">
            <h1 class="display-5 fw-bold text-dark"><?php echo e($team->name); ?></h1>
            <p class="text-muted mb-0"><?php echo e($fest->title); ?> - <?php echo e($event->title); ?></p>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="d-flex gap-2 mb-5">
        <?php if($team->registration_log->status !== 'approved'): ?>
            <form method="POST" action="/admin/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>/team/<?php echo e($team->id); ?>/approve">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success px-4">
                    <i class="bi bi-check-circle me-2"></i>Approve Team
                </button>
            </form>
            <form method="POST" action="/admin/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>/team/<?php echo e($team->id); ?>/reject">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger px-4">
                    <i class="bi bi-x-circle me-2"></i>Reject Team
                </button>
            </form>
        <?php else: ?>
            <button type="submit" class="btn btn-success px-4 disabled">
                <i class="bi bi-check-circle me-2"></i>Team Approved
            </button>
        <?php endif; ?>
    </div>

    <!-- Team Info Section -->
    <div class="row g-4">
        <!-- Leader & Members -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-header" style="border-bottom: 2px solid <?php echo e($team->color); ?>">
                    <h5 class="card-title mb-0">Team Structure</h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h6 class="text-muted mb-3">Team Leader</h6>
                        <div class="d-flex align-items-center gap-3">
                            <div class="avatar" style="background: <?php echo e($team->color); ?>; width: 40px; height: 40px; border-radius: 50%"></div>
                            <div>
                                <p class="mb-0 fw-bold"><?php echo e($team->leader->name); ?></p>
                                <small class="text-muted"><?php echo e($team->leader->university); ?></small>
                            </div>
                        </div>
                    </div>

                    <h6 class="text-muted mb-3">Team Members</h6>
                    <?php $__currentLoopData = $team->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="avatar" style="background: <?php echo e($team->color); ?>; width: 40px; height: 40px; border-radius: 50%"></div>
                            <div>
                                <p class="mb-0"><?php echo e($member->user->name); ?></p>
                                <small class="text-muted"><?php echo e($member->user->email); ?></small>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Team Description -->
        <div class="col-lg-8">
            <div class="card shadow-sm h-100">
                <div class="card-header" style="border-bottom: 2px solid <?php echo e($team->color); ?>">
                    <h5 class="card-title mb-0">Team Description</h5>
                </div>
                <div class="card-body markdown-body" style="overflow: auto; max-height: 400px;">
                    <?php echo Str::markdown($team->description); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- Registration Questions -->
    <div class="card shadow-sm mt-4">
        <div class="card-header" style="border-bottom: 2px solid <?php echo e($team->color); ?>">
            <h5 class="card-title mb-0">Registration Answers</h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="p-3 border rounded">
                            <small class="text-muted d-block mb-1">Question <?php echo e($loop->iteration); ?></small>
                            <p class="fw-bold mb-2"><?php echo e($question['question']->question); ?></p>
                            <div class="answer-box p-2 rounded" style="background: <?php echo e($team->color); ?>10; border: 1px solid <?php echo e($team->color); ?>30">
                                <?php echo e($question['answer'] ?? 'No answer provided'); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<style>
    .markdown-body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
        line-height: 1.6;
    }
    .markdown-body h1, .markdown-body h2, .markdown-body h3 {
        border-bottom: 1px solid #eaecef;
        padding-bottom: 0.3em;
    }
    .markdown-body code {
        background-color: rgba(175,184,193,0.2);
        padding: 0.2em 0.4em;
        border-radius: 6px;
    }
    .markdown-body pre {
        background-color: #f6f8fa;
        padding: 1em;
        border-radius: 6px;
        overflow: auto;
    }
    .markdown-body blockquote {
        color: #6a737d;
        border-left: 4px solid #dfe2e5;
        margin: 0;
        padding-left: 1em;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CS_Website\iutcs\resources\views/admin/team_details.blade.php ENDPATH**/ ?>