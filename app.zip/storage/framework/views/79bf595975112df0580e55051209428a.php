<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            line-height: 1.6;
            color: #000;
        }

        .header {
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
        }

        .logo {
            width: 80px;
            margin-bottom: 10px;
        }

        .section {
            margin: 25px 0;
            padding: 15px;
            /* border: 1px solid #aaa; */
            border-radius: 4px;
        }

        .section-title {
            border-bottom: 1px solid #000;
            padding-bottom: 8px;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .team-box {
            margin-bottom: 20px;
            /* border: 1px solid #444; */
            border-radius: 4px;
            padding: 15px;
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .team-header {
            font-weight: bold;
            margin-bottom: 12px;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .detail-item {
            padding: 8px;
            border-radius: 3px;
            /* border: 1px solid #ccc; */
        }

        .qa-table {
            width: 100%;
            margin: 10px 0;
            border-collapse: collapse;
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .qa-table th, .qa-table td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        .qa-table th {
            background: #eee;
            font-weight: bold;
        }

        .member-list {
            margin: 10px 0;
            padding-left: 15px;
        }

        .member-list li {
            margin-bottom: 6px;
        }

        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.9em;
            margin-left: 10px;
            background: #444;
            color: #fff;
        }

        .answer-section {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #aaa;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('rsx/logo.png')); ?>" class="logo">
        <h2 style="margin: 5px 0;">IUT Computer Society</h2>
        <h3 style="margin: 0;"><?php echo e($fest->title ?? 'Fest'); ?> - <?php echo e($event->title); ?></h3>
    </div>

    <div class="section">
        <h4 class="section-title">Event Information</h4>
        <div class="detail-grid">
            <div class="detail-item">
                <strong>Medium:</strong><br>
                <?php echo e($event->medium); ?>

            </div>
            <div class="detail-item">
                <strong>Location:</strong><br>
                <?php echo e($event->location); ?>

            </div>
            <div class="detail-item">
                <strong>Date:</strong><br>
                <?php echo e($event->start_date); ?> - <?php echo e($event->end_date); ?>

            </div>
        </div>
    </div>

    <div class="section">
        <h4 class="section-title">Participating Teams</h4>

        <?php $__currentLoopData = $teamData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="team-box">
                <h5 class="team-header">
                    <?php echo e($entry['team']->name); ?>

                    <span class="status-badge"><?php echo e($entry['team']->status); ?></span>
                </h5>

                <div class="member-section">
                    <strong>Team Members:</strong>
                    <ul class="member-list">
                        <?php $__currentLoopData = $entry['members']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <strong><?php echo e($member->name); ?></strong> (<?php echo e($member->role); ?>)<br>
                                <span><?php echo e($member->university); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <div class="answer-section">
                    <strong>Questionnaire Responses:</strong>
                    <table class="qa-table">
                        <thead>
                            <tr>
                                <th>Question</th>
                                <th>Answer</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $entry['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ans->question); ?></td>
                                    <td><?php echo e($ans->answer); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH D:\CS_Website\iutcs\resources\views/pdf/event_report.blade.php ENDPATH**/ ?>