

<?php $__env->startSection('main'); ?>
<div class="vh-100">
    <div class="container">
        <div class="row mt-5">
            <div class="col-12">
                <h1 class="display-6 fw-bold text-dark">
                    Participant Teams for <?php echo e($fest->title); ?>'s <?php echo e($event->title); ?>

                </h1>
                <hr class="border-dark opacity-50 my-4">
                <p class="lead text-muted">
                    This is the list of teams that have registered for the event. You may click on the teams to view details.
                </p>
            </div>
        </div>

        <div class="row mt-4 g-3">
            <div class="col-auto">
                <a href="/admin/event/<?php echo e($event->id); ?>/report" class="btn btn-outline-dark shadow-sm">
                    <i class="bi bi-printer me-2"></i>Print Report
                </a>
            </div>
            <div class="col-auto">
                <a href="/admin/event/<?php echo e($event->id); ?>/summary" class="btn btn-outline-danger shadow-sm">
                    <i class="bi bi-file-earmark-pdf me-2"></i>PDF Summary
                </a>
            </div>
            <div class="col-auto">
                <a href="/admin/event/<?php echo e($event->id); ?>/csv" class="btn btn-outline-success shadow-sm">
                    <i class="bi bi-file-earmark-spreadsheet me-2"></i>Export CSV
                </a>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="fw-semibold px-4">Team Name</th>
                                    <th class="fw-semibold">Team Lead</th>
                                    <th class="fw-semibold">Members</th>
                                    <th class="fw-semibold">Status</th>
                                    <th class="fw-semibold text-end px-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-top">
                                    <td class="px-4">
                                        <a href="/admin/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>/team/<?php echo e($team->id); ?>" 
                                           class="text-decoration-none text-dark fw-semibold">
                                            <?php echo e($team->name); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="/profile/<?php echo e($team->leader->id); ?>" 
                                           class="text-decoration-none text-primary">
                                            <?php echo e($team->leader->name); ?>

                                            
                                        </a>
                                    </td>
                                    <td>
                                        <ul class="list-unstyled mb-0">
                                            <?php $__currentLoopData = $team->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="/profile/<?php echo e($member['id']); ?>"
                                                   class="text-decoration-none text-muted">
                                                    <?php echo e($member['name']); ?>                                                    
                                                </a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <?php
                                            $status = $team->registration_log->status;
                                            $badgeStyles = [
                                                'approved' => 'bg-success',
                                                'pending' => 'bg-warning',
                                                'rejected' => 'bg-danger'
                                            ];
                                        ?>
                                        <span class="badge <?php echo e($badgeStyles[$status] ?? 'bg-secondary'); ?> text-white rounded-pill">
                                            <?php echo e(ucfirst($status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-end px-4">
                                        <?php if($team->registration_log->status !== 'approved'): ?>
                                            <div class="d-flex justify-content-end gap-2">
                                                <form method="POST" 
                                                      action="/admin/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>/team/<?php echo e($team->id); ?>/approve">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" 
                                                            class="btn btn-sm btn-outline-success rounded-pill px-3">
                                                        <i class="bi bi-check-circle me-1"></i>Approve
                                                    </button>
                                                </form>
                                                
                                                <form method="POST" 
                                                      action="/admin/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>/team/<?php echo e($team->id); ?>/reject">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" 
                                                            class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                                        <i class="bi bi-x-circle me-1"></i>Reject
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-5 text-muted">
                                        No teams have registered yet
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CS_Website\iutcs\resources\views/admin/participants.blade.php ENDPATH**/ ?>