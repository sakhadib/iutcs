

<?php $__env->startSection('main'); ?>
<main>
    <div class="py-12">
      <div class="container mx-auto px-4">
        <div class="text-left mb-12">
          
        </div>

        <div class="flex flex-col gap-y-2">
          <!-- ONGOING FESTS -->
          
            <section class="mt-2 flex items-center justify-between">
            <h2
              class="text-2xl font-bold mb-6 flex items-center text-left"
            >
              <span class="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
              Current Fest
            </h2>
            <?php if(session('role') === 'admin'): ?>
              <a 
              href="/admin/fests/create" 
              class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-md font-medium transition-colors"
              >
              Create New Fest
              </a>
            <?php endif; ?>
            </section>
            
            <?php if($ongoing_fest): ?>
            <div class="grid grid-cols-1 gap-6 mt-6">
              <!-- FEST CARD -->
              <div
              class="bg-white rounded-xl overflow-hidden  border border-gray-100 hover:shadow-xl transition-shadow w-full"
              >
              <div class="md:flex">
                <div class="md:w-1/3 h-48 md:h-auto bg-red relative">
                <div
                  class="absolute inset-0 flex items-center justify-center text-white text-xl font-bold"
                >
                  <img src="<?php echo e($ongoing_fest->image); ?>" alt="Fest Image" class="w-full h-full object-cover">
                </div>
                </div>
                <div class="p-6 md:w-2/3">
                <div class="flex flex-wrap gap-3 mb-3">
                  <span
                  class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium flex items-center"
                  >
                    <?php echo e(\Carbon\Carbon::parse($ongoing_fest->start_date)->format('F, Y')); ?>

                  </span>
                  <span
                  class="bg-navy/10 text-navy px-3 py-1 rounded-full text-sm font-medium flex items-center"
                  >
                  <?php echo e($ongoing_fest->location); ?>

                  </span>
                </div>
                <h3 class="text-2xl font-bold mb-3"><?php echo e($ongoing_fest->title); ?></h3>
                <p class="text-gray-600 mb-6">
                  <?php echo e($ongoing_fest->description); ?>

                </p>
                <div class="flex justify-between items-center">
                  <span class="text-gray-700"><?php echo e($ongoing_fest->events_count); ?> Events</span>
                  <a
                  href="/fest/<?php echo e($ongoing_fest->id); ?>"
                  class="bg-red hover:bg-red/90 text-white px-4 py-2 rounded-md font-medium transition-colors inline-flex items-center"
                  >
                  View Details
                  </a>
                </div>
                </div>
              </div>
              </div>
            </div>
          </section>
          <?php endif; ?>
          
        </div>
      </div>
    </div>
  </main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CS_Website\iutcs\resources\views/frontend/fests.blade.php ENDPATH**/ ?>