

<?php $__env->startSection('main'); ?>



 <div class="festival-page">
    <!-- Hero Section -->
    <div class="relative h-[80vh] bg-black">
      <img src="<?php echo e($fest->image); ?>" alt="Event Cover" class="w-full h-full object-cover opacity-75 bg-fixed">
      <div class="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
      <div class="absolute bottom-0 left-0 right-0 text-white p-8">
      <div class="container mx-auto">
        <h1 class="text-4xl md:text-6xl font-bold mb-4"><?php echo e($fest->title); ?></h1>
        <div class="flex items-center space-x-4">
        <span class="bg-purple-600 text-sm px-3 py-1 rounded-full">
          <i class="bi bi-geo-alt-fill mr-2"></i><?php echo e($fest->location); ?>

        </span>
        <span class="bg-green-600 text-sm px-3 py-1 rounded-full">
          <i class="bi bi-calendar-event mr-2"></i> <?php echo e(count($events)); ?> Events
        </span>
        </div>
      </div>
      </div>
    </div>



  <!-- Main Content -->
  <div class="container py-5">
      <div class="tab-content">
          <!-- Overview Tab -->
          <div class="tab-pane fade show active" id="overview">
              <div class="row g-5">
                  <div class="col-lg-12">
                      <div class="content-card">
                          <h3 class="section-title mb-4">Festival Details</h3>
                          <div class="prose">
                              <?php echo Str::markdown($fest->description); ?>

                          </div>
                      </div>
                  </div>                     
              </div>
          </div>

          <!-- Events Tab -->
          <div>
              <div class="d-flex justify-content-between align-items-center mb-4 mt-10">
                  <h3 class="section-title">Featured Events</h3>
                  <?php if(session('role') == 'admin'): ?>
                  <a href="/admin/fest/<?php echo e($fest->id); ?>/event/create" class="btn btn-dark">
                      <i class="bi bi-plus-circle me-2"></i>Add New Event
                  </a>
                  <?php endif; ?>
              </div>

              <div class="row g-4">
                  <?php if(count($events) > 0): ?>
                      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                          <div class="event-card shadow-lg hover-lift transform transition-transform duration-300 hover:scale-105">
                          <div class="event-image relative overflow-hidden rounded-t-lg">
                            <img src="<?php echo e($event->image); ?>" alt="<?php echo e($event->title); ?>" class="w-full h-48 object-cover">
                            <div class="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-75"></div>
                            <div class="absolute bottom-2 left-2 text-white text-sm bg-purple-600 px-2 py-1 rounded">
                            <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('M j, Y')); ?>

                            </div>
                            <div class="absolute bottom-2 right-2 text-white text-sm bg-green-600 px-2 py-1 rounded">
                            <?php echo e(Str::limit($event->location, 25)); ?>

                            </div>
                            <div class="absolute top-2 right-2 text-white text-sm bg-indigo-600 px-2 py-1 rounded">
                            BDT <?php echo e($event->registration_fee); ?>

                            </div>
                          </div>
                          <div class="event-body p-4 bg-white rounded-b-lg">
                            <h4 class="event-title text-lg font-semibold text-gray-800 mb-2">
                            <?php echo e(Str::limit($event->title, 40)); ?>

                            </h4>
                            <div class="d-grid">
                            <a href="/fest/<?php echo e($fest->id); ?>/event/<?php echo e($event->id); ?>" 
                               class="btn btn-lg btn-dark w-100">
                              View Event Page
                            </a>
                            </div>
                          </div>
                          </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                      <div class="col-12">
                          <div class="empty-state">
                              <i class="bi bi-calendar-x"></i>
                              <p>No events announced yet</p>
                              <?php if(session('role') == 'admin'): ?>
                              <a href="/admin/fest/<?php echo e($fest->id); ?>/event/create" class="btn btn-dark mt-3">
                                  Create First Event
                              </a>
                              <?php endif; ?>
                          </div>
                      </div>
                  <?php endif; ?>
              </div>
          </div>
      </div>
  </div>
</div>

<style>
.hero-section {
  height: 70vh;
  min-height: 600px;
  background: linear-gradient(45deg, #0f172a, #1e293b);
}

.gradient-overlay {
  background: linear-gradient(to top, rgba(15, 23, 42, 1) 10%, rgba(15, 23, 42, 0.2) 100%);
  z-index: 1;
}

.hero-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  position: absolute;
  z-index: 0;
}

.hero-content {
  position: relative;
  z-index: 2;
}

.event-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  position: relative;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.event-image img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.event-body {
  padding: 1.5rem;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
}

.event-title {
  font-weight: 600;
  margin-bottom: 0.75rem;
  min-height: 3rem;
}

.event-meta {
  margin-bottom: auto;
}

.meta-item {
  font-size: 0.9rem;
  color: #64748b;
  margin-bottom: 0.5rem;
}

.empty-state {
  text-align: center;
  padding: 4rem;
  color: #64748b;
  border: 2px dashed #e2e8f0;
  border-radius: 12px;
}
</style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CS_Website\iutcs\resources\views/frontend/fest-details.blade.php ENDPATH**/ ?>